const express = require('express');
const path = require('path');
const fs = require('fs');

const app = express();
const imageFolder = path.join(__dirname, 'images');

// Endpoint to get a random image URL
app.get('/api/random-image', (req, res) => {
  fs.readdir(imageFolder, (error, files) => {
    if (error) {
      console.error('Error:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      const randomIndex = Math.floor(Math.random() * files.length);
      const randomImage = files[randomIndex];
      const imageUrl = `/images/${randomImage}`;
      res.json({ imageUrl });
    }
  });
});

// Serve the images statically
app.use('/images', express.static(imageFolder));

// Start the server
const port = 3001;
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});

