import React, { useState, useEffect } from 'react';

const RandomImage = () => {
  const [imageUrl, setImageUrl] = useState('');

  useEffect(() => {
    fetch('/api/random-image')
      .then((response) => response.json())
      .then((data) => setImageUrl(data.imageUrl))
      .catch((error) => console.error('Error:', error));
  }, []);

  return (
    <div>
      {imageUrl ? (
        <img src={imageUrl} alt="Random Image" />
      ) : (
        <p>Loading...</p>
      )}
    </div>
  );
};

export default RandomImage;

