import React, { useState, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const RandomImage = () => {
  const [imageUrl, setImageUrl] = useState('');

  const fetchRandomImage = () => {
    fetch('/api/random-image')
      .then((response) => response.json())
      .then((data) => setImageUrl(data.imageUrl))
      .catch((error) => console.error('Error:', error));
  };

  useEffect(() => {
    fetchRandomImage();
  }, []);

  const handleChangeImage = () => {
    fetchRandomImage();
  };

  return (
    <div
      className="container d-flex flex-column align-items-center justify-content-center"
      style={{ backgroundColor: '#87CEFA', minHeight: '100vh' }}
    >
      <h1 className="text-center mb-4" style={{ color: '#000080' }}>
        Random Image App
      </h1>
      {imageUrl ? (
        <div className="text-center">
          <img
            src={imageUrl}
            alt="Random Image"
            className="img-fluid rounded"
            style={{ width: '30vw', height: 'auto' }}
          />
          <button
            onClick={handleChangeImage}
            className="btn btn-primary mt-3"
            style={{ backgroundColor: '#0074D9', borderColor: '#0074D9' }}
          >
            Change Image
          </button>
        </div>
      ) : (
        <p>Loading...</p>
      )}
    </div>
  );
};

export default RandomImage;

