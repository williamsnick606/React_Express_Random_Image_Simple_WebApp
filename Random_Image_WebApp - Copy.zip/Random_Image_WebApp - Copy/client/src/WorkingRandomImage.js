import React, { useState, useEffect } from 'react';

const RandomImage = () => {
  const [imageUrl, setImageUrl] = useState('');

  const fetchRandomImage = () => {
    fetch('/api/random-image')
      .then((response) => response.json())
      .then((data) => setImageUrl(data.imageUrl))
      .catch((error) => console.error('Error:', error));
  };

  useEffect(() => {
    fetchRandomImage();
  }, []);

  const handleChangeImage = () => {
    fetchRandomImage();
  };

  return (
    <div>
      {imageUrl ? (
        <div>
          <img src={imageUrl} alt="Random Image" />
          <button onClick={handleChangeImage}>Change Image</button>
        </div>
      ) : (
        <p>Loading...</p>
      )}
    </div>
  );
};

export default RandomImage;

