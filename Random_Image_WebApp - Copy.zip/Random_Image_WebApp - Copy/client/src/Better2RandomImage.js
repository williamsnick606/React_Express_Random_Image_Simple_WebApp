import React, { useState, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const RandomImage = () => {
  const [imageUrl, setImageUrl] = useState('');

  const fetchRandomImage = () => {
    fetch('/api/random-image')
      .then((response) => response.json())
      .then((data) => setImageUrl(data.imageUrl))
      .catch((error) => console.error('Error:', error));
  };

  useEffect(() => {
    fetchRandomImage();
  }, []);

  const handleChangeImage = () => {
    fetchRandomImage();
  };

  return (
    <div className="container text-center pt-5">
      <h1 className="mb-4" style={{ color: '#3D9970' }}>
        Random Image App
      </h1>
      {imageUrl ? (
        <div>
          <img
            src={imageUrl}
            alt="Random Image"
            className="img-fluid rounded"
            style={{ width: '30vw', height: 'auto' }}
          />
          <button
            onClick={handleChangeImage}
            className="btn btn-primary mt-3"
            style={{ backgroundColor: '#0074D9', borderColor: '#0074D9' }}
          >
            Change Image
          </button>
        </div>
      ) : (
        <p>Loading...</p>
      )}
    </div>
  );
};

export default RandomImage;

