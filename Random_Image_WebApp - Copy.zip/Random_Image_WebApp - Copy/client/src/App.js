import React from 'react';
import RandomImage from './RandomImage';

const App = () => {
  return (
    <div>
      <h1>Random Image App</h1>
      <RandomImage />
    </div>
  );
};

export default App;
